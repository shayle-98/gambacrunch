
function joinDiscord() {
  alert("Connect your Discord invite link here.");
}

console.log("GambaCrunch loaded.");
